﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM_Cooking
{
    class Recette
    {
        private string nom_r;
        private string type;
        private string descriptif;
        private float prix;

        public Recette()
        { }
        public Recette(string nom_r,string type,string descriptif,float prix)
        {
            this.Nom_r = nom_r;
            this.Type = type;
            this.Descriptif = descriptif;
            this.Prix = prix;
        }

        public string Nom_r { get => nom_r; set => nom_r = value; }
        public string Type { get => type; set => type = value; }
        public string Descriptif { get => descriptif; set => descriptif = value; }
        public float Prix { get => prix; set => prix = value; }

        //METHODES
        public string ToString()
        {
            return "nom: "+this.nom_r + "\n descriptif: " + this.descriptif + "\nPrix: " + this.prix+"\n";
        }
        public void NomR()
        {
            Console.WriteLine("donner le nom du plat");
            this.nom_r = Console.ReadLine();
        }
        public void DesR()
        {
            Console.WriteLine("donner une description du plat");
            this.Descriptif = Console.ReadLine();
        }
        public void PrixR()
        {
            Console.WriteLine("donner le prix du plat");
            this.Prix = int.Parse(Console.ReadLine());
        }
        public void typeR()
        {
            int n = 0;
            int i = 0;
            List<string> L = new List<string>{"entrée", "plat", "dessert"};
            foreach (string c in L)
            {
                Console.WriteLine(i+") "+c);
                i++;
            }
            do
            {
                n = int.Parse(Console.ReadLine());
            } while (n < 0 && n > 2);
            this.type = L[n];
        }
    }
}
