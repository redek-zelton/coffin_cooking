﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM_Cooking
{
    class Fournisseur
    {
        private string nom_f;

        public Fournisseur()
        { }
        public Fournisseur(string nom_f)
        { this.Nom_f = nom_f; }

        public string Nom_f { get => nom_f; set => nom_f = value; }

        //METHODES

    }
}
