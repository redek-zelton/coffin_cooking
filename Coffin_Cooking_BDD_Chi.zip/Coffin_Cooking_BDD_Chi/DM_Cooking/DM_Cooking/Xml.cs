﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DM_Cooking
{
    public class Xml
    {
        string nom_f;
        string nom_p;
        int qte;

        public Xml()
        { }
        public Xml(string nom_f,string nom_p,int qte)
        {
            this.Nom_f = nom_f;
            this.Nom_p = nom_p;
            this.qte = qte;
        }
        public string Nom_f { get => nom_f; set => nom_f = value; }
        public string Nom_p { get => nom_p; set => nom_p = value; }
        public int Qte { get => qte; set => qte = value; }

        //METHODE
        public string ToString()
        { return "fournisseur : " + this.nom_f + "\n produit : " + this.nom_p + "\n nombre à commander : " + this.qte + "\n"; }
    }
}
