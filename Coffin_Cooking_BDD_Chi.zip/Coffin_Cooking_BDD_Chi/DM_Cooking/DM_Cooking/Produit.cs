﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM_Cooking
{
    class Produit
    {
        private string nom_p;
        private string categorie;
        private int stock;
        private int stock_min;
        private int stock_max;
        private string nom_f;

        public Produit()
        { }
        public Produit(string nom_p,string categorie,int stock,int stock_min,int stock_max, string nom_f)
        {
            this.Nom_p = nom_p;
            this.Categorie = categorie;
            this.Stock = stock;
            this.Stock_min = stock_min;
            this.Stock_max = stock_max;
            this.Nom_f = nom_f;
        }

        public string Nom_p { get => nom_p; set => nom_p = value; }
        public string Categorie { get => categorie; set => categorie = value; }
        public int Stock { get => stock; set => stock = value; }
        public int Stock_min { get => stock_min; set => stock_min = value; }
        public int Stock_max { get => stock_max; set => stock_max = value; }
        public string Nom_f { get => nom_f; set => nom_f = value; }



        //METHODE
        public string jauger()
        {
            string jauge = "";
            if (this.Stock > this.Stock_max)
            { jauge = "Surstock"; }
            if (this.Stock < this.Stock_min)
            { jauge = "Pénurie"; }
            if (this.Stock > this.Stock_min && this.Stock<this.Stock_min*2)
            { jauge = " Presque Pénurie"; }
            if (this.Stock < this.Stock_max && this.Stock > this.Stock_min * 2)
            { jauge = " stock bien gérer"; }
            return jauge;
        }
        public string ToString()
        {
            return this.Nom_f + " -> " + this.Nom_p + " " + this.jauger()+" : " + this.Stock;
        }
    }
}
