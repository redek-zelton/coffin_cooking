﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CHI_ANTOINE_GROUPE_B
{
    class Program
    {
        static int SaisiePositif()
        {
            int val;
            do// si négative, relance une valeur 
            {
                Console.WriteLine("saisir un ent positif");
                val = int.Parse(Console.ReadLine());
            } while (val < 1);
            return val;// donne la valeur positive stricte
        }


        static bool Parite(int nombre)
        {
            int sous = (nombre / 10) * 10;
            sous = nombre - sous;// on garde que le chiffre unitaire
            do
            {
                sous = sous - 2;
            } while (sous >= 1);
            return (sous == 0);// true 0 ou False 1
        }
        static void TestParite()
        {
            int a = SaisiePositif();
            if (Parite(a) == true) 
            { Console.WriteLine(a + " est pair"); }
            else
            { Console.WriteLine(a + " est impair"); }
        }
        static bool comptabilise()
        {
            Random generateur = new Random();
            double x = generateur.Next(0, 101); x = x / 100;// pour avoir x[0,1]
            System.Threading.Thread.Sleep(2);// pour eviter x=y tout le temps
            double y = generateur.Next(0, 101); y = y / 100;// pour avoir y[0,1]
            return ((Math.Pow(x, 2) + Math.Pow(y, 2)) <= 1);// x^2+y^2<=1
        }
        static double ApproxPi(double p,int n)//(double,int) pour avoir un double 
        {
            double pi = 4*p/n;// 4*pi/4
            return pi;
        }

        static double MonteCarlo(int n)
        {
            double p = 0;
            bool[] tableau= new bool[n];
            for(int i=0;i<n;i++)
            {
                tableau[i] = comptabilise();
                if(tableau[i]==true)
                { p++; }
            }
            return (ApproxPi(p, n));
        }
        static void TestApproximationPi()
        {
            int n = SaisiePositif();// positif stricte
            double pi = MonteCarlo(n);
            Console.WriteLine("la valeur approximative de Pi est " + pi);

        }
        static int[] GenererTableauAleatoire(int taille,int valeurMin,int valeurMax)
        {
            int[] resultat = null;
            if((taille>0)&&(valeurMin<valeurMax))
            {
                resultat = new int[taille];
                Random rand = new Random();//generateur aleatoire
                for (int i = 0; i < resultat.Length; i++)
                {
                    resultat[i] = rand.Next(valeurMin, valeurMax + 1);//dans intervalle[min,max]
                }
            }
            return resultat;
        }
        static void AfficherTableau(int[] tableau)
        {
            if (tableau == null)
            { Console.WriteLine("(tableau null)"); }
            else
            {
                if (tableau.Length == 0)// c'est un cas possible
                { Console.WriteLine("(tableau vide)"); }
                else //cas genaral
                {
                    int i = 0;
                    while (i < tableau.Length - 1)// tratement du premier à n-1
                    {
                        Console.Write(tableau[i]);
                        Console.Write(";");
                        i++;
                    }
                    Console.Write(tableau[i]);
                }
            }
            Console.WriteLine();
        }

        static int NombreValeurImpaire(int[] tableau)
        {
            int compteur = 0;// compteur des nb impaires
            for(int i=0;i<=tableau.Length-1;i++)
            {
                if (tableau[i]%2==1)
                { compteur++; }// +1 pour chaque impaire
            }
            return compteur;// fin compteur
        }
        static void TestNombreValeurImpaires()
        {
            Console.WriteLine("saisir la taille du tableau");
            int taille = SaisiePositif();// pour eviter un tableau vide
            Console.WriteLine("saisir une valeur minimale");
            int valeurMinimale = int.Parse(Console.ReadLine());
            Console.WriteLine("saisir une valeur maximale");
            int valeurMaximale = int.Parse(Console.ReadLine());
            if (valeurMinimale > valeurMaximale)
            { Console.WriteLine("comptage impossible"); }// cas possible
            else
            {
                int[] tableau = GenererTableauAleatoire(taille, valeurMinimale, valeurMaximale);
                AfficherTableau(tableau);
                int compteur = NombreValeurImpaire(tableau);// de à à tableau.Length-1
                Console.WriteLine("il ya " + compteur + " de nombres impaires");
            }

        }
        static void Main(string[] args)
        {
            TestParite();// rapide
            TestApproximationPi();// lent car il ya un freeze
            TestNombreValeurImpaires();// rapide et affiche le tableau + nb impaire
            Console.ReadKey();
        }
    }
}
