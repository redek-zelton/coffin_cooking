﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DM_Cooking
{
    class Program
    {

        // tableau de bord
        static void tableau_de_bord(MySqlConnection maConnexion)
        {
            // CDR D'OR
            Console.WriteLine();
            Console.WriteLine("\n#######################################");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "select cdr.nom from cdr,recette,commander where cdr.id=recette.id and commander.nom_r=recette.nom_r group by cdr.nom order by count(cdr.nom) DESC;";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            List<string> LCDR = new List<string>();
            while (reader.Read())
            {
                LCDR.Add(reader.GetString(0));
            }
            reader.Close();
            Console.WriteLine("# CDR D'OR :" + LCDR[0]);
            Console.WriteLine("#");

            // CDR DE LA SEMAINE
            DateTime today = DateTime.Now;
            MySqlParameter Today = new MySqlParameter("@Today", MySqlDbType.DateTime);
            Today.Value = today;
            commande.CommandText = "select cdr.nom from cdr,recette natural join commander where cdr.id=recette.id and datediff(periode,@Today)<7 group by cdr.nom order by count(cdr.nom) DESC;";
            commande.Parameters.Add(Today);
            reader = commande.ExecuteReader();
            List<string> SCDR = new List<string>();
            while (reader.Read())
            {
                LCDR.Add(reader.GetString(0));
            }
            reader.Close();
            Console.WriteLine("# CDR DE LA SEMAINE :" + LCDR[0]);
            Console.WriteLine("#");

            // TOP 5 des recettes commander
            commande.CommandText = "select nom_r from commander group by nom_r order by count(nom_r) DESC;";
            MySqlDataReader reader1;
            reader1 = commande.ExecuteReader();
            List<string> LRece = new List<string>();
            while (reader1.Read())
            {
                LRece.Add(reader1.GetString(0));
            }
            reader1.Close();
            for(int i=0;i<5-LRece.Count;i++)
            {
                LRece.Add("Place à prendre");
            }
            Console.WriteLine("#      TOP 5 RECETTES");
            int cpt = 1; // classement
            foreach (string l in LRece) 
            {
                Console.WriteLine("# TOP" + cpt + ": " + l);
                cpt++;
            }
            Console.WriteLine("######################################\n");
        }

        // interface
        static void Choix(MySqlConnection maConnexion)
        {
            int nombre;
            do
            {
                do
                {
                    Console.WriteLine("\n\n\n");
                    AFtxt("Menu.txt");
                    tableau_de_bord(maConnexion);
                    Console.WriteLine("choisir 1 à 5");
                    nombre = int.Parse(Console.ReadLine());
                } while (nombre <= 0 && nombre > 4);
                switch (nombre)
                {
                    case 1: { identificationClient(maConnexion); break; }
                    case 2: { identificationCDR(maConnexion); break; }
                    case 3: { ModuleCooking(maConnexion); break; }
                    case 4: { ModeDemo(maConnexion); break; }
                }
            } while (nombre != 5);
            Console.WriteLine("FIN DE PROGRAMME !");

        }

        static void AFtxt(string nomFich)
        {
            StreamReader fichLecture = new StreamReader(nomFich);
            string ligne = " ";
            while (fichLecture.Peek() > 0)
            {
                ligne = fichLecture.ReadLine();
                Console.WriteLine(ligne);
            }
            fichLecture.Close(); // ON FERME LE FICHIER   ➔ Etape 4
        } //afficher le txt





        #region MODULE DEMO
        static void ModeDemo(MySqlConnection maConnexion)
        {

            int n = 0;
            do
            {
                Console.WriteLine("\n");
                AFtxt("ModeDemo.txt");
                Console.WriteLine("choisir module");
                n = int.Parse(Console.ReadLine());
                if (n == 1)
                {
                    Afficher(maConnexion);
                }
                if(n==2)
                {
                    ingredient(maConnexion);
                }
            } while (n == 1 || n==2);
        }
        static void NbClient(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT count(*) FROM client";
            MySqlDataReader reader1;
            reader1 = commande.ExecuteReader();
            int nbclient = 0;
            while (reader1.Read())
            {
                nbclient = reader1.GetInt32(0);
            }
            reader1.Close();
            Console.WriteLine("il y a actuellement : " + nbclient + " clients !");
        }
        static void AfficherCDR(MySqlConnection maConnexion)
        {
            Console.WriteLine("\nLa liste des CDR\n");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "select id,nom,point,count(recette.nom_r) from cdr natural join recette group by nom order by nom ASC;";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            List<string> id = new List<string>();
            List<string> nom = new List<string>();
            List<float> point = new List<float>();
            List<string> nom_r = new List<string>();
            while (reader.Read())
            {
                id.Add(reader.GetString(0));
                nom.Add(reader.GetString(1));
                point.Add(reader.GetFloat(2));
                nom_r.Add(reader.GetString(3));
            }
            reader.Close();
            MySqlCommand commande1 = maConnexion.CreateCommand();
            commande1.CommandText = "select cdr.nom,count(*)from cdr natural join recette,commander where commander.nom_r=recette.nom_r group by cdr.nom;;";
            MySqlDataReader reader1;
            reader1 = commande1.ExecuteReader();
            List<string> nomCompare = new List<string>();
            List<int> dish = new List<int>();
            while (reader1.Read())
            {
                nomCompare.Add(reader1.GetValue(0).ToString());
                dish.Add(reader1.GetInt32(1));
            }
            reader1.Close();
            for (int i = 0; i < nom.Count; i++)
            {
                if (nomCompare.Contains(nom[i]))
                { Console.WriteLine("ID: " + id[i] + " " + nom[i] + " -> point: " + point[i] + " nbr recette: " + nom_r[i] + " nbr plat commandé: " + dish[nomCompare.IndexOf(nom[i])]); }
                else
                { Console.WriteLine("ID: " + id[i] + " " + nom[i] + " -> point: " + point[i] + " nbr recette: " + nom_r[i] + " nbr plat commandé: " + 0); }

            }
            // nombre de cdr
            commande1.CommandText = "SELECT count(*) FROM cdr";
            MySqlDataReader reader2;
            reader2 = commande1.ExecuteReader();
            int nbcdr = 0;
            while (reader2.Read())
            {
                nbcdr = reader2.GetInt32(0);
            }
            reader2.Close();
            Console.WriteLine("il y a actuellement : " + nbcdr + " cdr !");
        }
        static void NbRecette(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT count(*) FROM recette";
            MySqlDataReader reader1;
            reader1 = commande.ExecuteReader();
            int nb = 0;
            while (reader1.Read())
            {
                nb = reader1.GetInt32(0);
            }
            reader1.Close();
            Console.WriteLine("il y a actuellement : " + nb + " recette !");
        }
        static void ProduitRup(MySqlConnection maConnexion)
        {
            Console.WriteLine("La liste des Produits < 2*qté min");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT nom_p,stock FROM produit where stock<stock_min*2 order by nom_f";
            MySqlDataReader reader;
            List<string> Lp = new List<string>();
            List<int> Ls = new List<int>();
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Lp.Add(reader.GetString(0));
                Ls.Add(reader.GetInt32(1));
            }
            reader.Close();
            for(int i=0;i<Lp.Count;i++)
            { Console.WriteLine("article: " + Lp[i] + "          stock: " + Ls[i]); }

        }
        static void Afficher(MySqlConnection maConnexion)
        {
            Console.WriteLine("###############################################");
            NbClient(maConnexion);
            Console.WriteLine("\n");
            AfficherCDR(maConnexion);
            Console.WriteLine("\n");
            NbRecette(maConnexion);
            Console.WriteLine("\n");
            ProduitRup(maConnexion);
            Console.WriteLine("###############################################");
        }
        static void ingredient(MySqlConnection maConnexion)
        {
            Console.WriteLine("Donnez un produit");
            MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);// prend le nom
            string prod= Console.ReadLine();
            nom_p.Value = prod;
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT produit.matiere,nom_r,quantite FROM composer natural join produit where nom_p=@nom_p";
            MySqlDataReader reader;
            commande.Parameters.Add(nom_p);
            reader = commande.ExecuteReader();
            Console.WriteLine("La liste des recettes avec "+prod+"------------------------");
            while (reader.Read())
            {
                string mat = reader.GetString(0);
                if (mat == "solide")
                { Console.WriteLine("recette: " + reader.GetString(1) + "    quantité: " + reader.GetInt32(2)); }
                if (mat == "poudre")
                { Console.WriteLine("recette: " + reader.GetString(1) + "    quantité: " + reader.GetInt32(2)+" g"); }
                if (mat== "liquide")
                { Console.WriteLine("recette: " + reader.GetString(1) + "    quantité: " + reader.GetInt32(2)+" mL"); }
            }
            reader.Close();
            Console.WriteLine("------------------------------------------------------------");
        }
        #endregion







        #region MODULE CLIENT
        static client Coordonnées(MySqlConnection maConnexion, string nom)
        {
            client C1 = new client();
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
            name.Value = nom;
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT * FROM client where nom=@name";
            commande.Parameters.Add(name);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                C1.Nom = reader.GetString(0);
                C1.Tel = reader.GetInt32(1);
            }
            reader.Close();
            return C1;
        }
        static void identificationClient(MySqlConnection maConnexion)
        {
            string nom = ""; // saisir nom
            string test = ""; // verifiacteur de nom
            Console.WriteLine("êtes-vous un client ?(true/false)");
            bool commen = Boolean.Parse(Console.ReadLine());
            if (commen == false)
            { AjouterClient(maConnexion); }
            else
            {
                Console.WriteLine("Veuillez à vous identifier !");
                MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);// prend le nom
                iden.Value = nom;
                Console.WriteLine("donner votre nom");
                nom = Console.ReadLine();
                iden.Value = nom;
                MySqlCommand commande = maConnexion.CreateCommand();
                commande.CommandText = "SELECT nom FROM client where nom=@iden";
                commande.Parameters.Add(iden);
                MySqlDataReader reader;
                reader = commande.ExecuteReader();
                if (reader.Read())
                {
                    test = reader.GetString(0);
                }
                reader.Close();
                if (test == nom)
                { ModuleClient(maConnexion, nom); }
                else
                { Console.WriteLine("ECHEC !!!"); }
            }
        }
        static void ModuleClient(MySqlConnection maConnexion,string nom)
        {
            client C = Coordonnées(maConnexion, nom);
            int n = -1;
            do
            {
                Console.WriteLine("\n");
                Console.WriteLine("BIENVENUE DANS VOTRE ESPACE " + C.Nom + "   " + C.Tel);
                AFtxt("ModuleClient.txt");
                Console.WriteLine("choisir module");
                n = int.Parse(Console.ReadLine());
                if (n == 1)
                {
                    AfficherCarte(maConnexion);
                }
                if (n == 2)
                {
                    PasserCommande(maConnexion,nom);
                }
                if (n == 3)
                {
                    ModifierClient(maConnexion,C);
                }
            } while (n == 1 || n == 2 || n==3);
        }
        // afficher la carte
        static void AfficherCarte(MySqlConnection maConnexion)
        {
            Console.WriteLine("\nLa liste des Recettes\n");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT * FROM recette";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            List<String> Lnom_r = new List<string>();
            List<String> Ltype = new List<string>();
            List<String> Ldescr = new List<string>();
            List<int> Lprix = new List<int>();
            while (reader.Read())
            {
                Lnom_r.Add(reader.GetString(0));
                Ltype.Add(reader.GetString(1));
                Ldescr.Add(reader.GetString(2));
                Lprix.Add(reader.GetInt32(3));
            }
            reader.Close();
            List<Recette> LR = new List<Recette>();
            for (int i = 0; i < Lprix.Count; i++)
            {
                Recette R = new Recette(Lnom_r[i], Ltype[i], Ldescr[i], Lprix[i]);
                LR.Add(R);
            }
            int n = 0;
            int k = 0;
            List<string> L = new List<string> { "entrée", "plat", "dessert", "TOUS" };
            foreach (string c in L)
            {
                Console.WriteLine(k + ") " + c);
                k++;
            }
            do
            {
                n = int.Parse(Console.ReadLine());
            } while (n < 0 && n > 3);
            if (n == 3)
            {
                Console.WriteLine("-----La Carte------");
                foreach (Recette R in LR)
                {
                    Console.WriteLine(R.ToString());
                }
            }
            else
            {
                Console.WriteLine("--------" + L[n].ToUpper() + "--------");
                List<Recette> LR2 = LR.FindAll(delegate (Recette r)
                { return r.Type == L[n]; });
                foreach (Recette recette in LR2)
                { Console.WriteLine(recette.ToString()); }
            }
        }


        // La partie commande très longue
        // La partie réduction en cours(. . . )
        static void PasserCommande(MySqlConnection maConnexion,string nom)// nom client
        {
            bool suite = false;
            Console.WriteLine("Attention avant de valider vos plats, il faut que vous notez sur une feuille ce que vous avez choisi.\n Lorsqu'un plat est validé, le retour en arrière est impossible !\n Merci de votre compréhension .");
            List<string> ListPlat = new List<string>();
            List<int> ListQte = new List<int>();
            List<int> ListePrice = new List<int>();
            int TotalPrice = 0;
            int cpt = 1;
            do
            {
                bool valide = false;
                Console.WriteLine("Choisir votre " + cpt + "eme plat");
                string plat = Console.ReadLine();
                Console.WriteLine("donnez la quantité de :" + plat);
                int qte = int.Parse(Console.ReadLine());
                Console.WriteLine("êtes-vous sûr ? " + qte + " " + plat + "  (true/false)");
                valide = Boolean.Parse(Console.ReadLine());
                if (valide)
                {
                    int price = GetPrice(maConnexion, plat);
                    if (price == 0)
                    { Console.WriteLine("Plat non existant"); }
                    else
                    {
                        cpt++;
                        ListPlat.Add(plat);
                        ListQte.Add(qte);
                        ListePrice.Add(price);
                        TotalPrice = TotalPrice + qte * price;
                        Récap(ListPlat, ListQte, ListePrice, TotalPrice);
                    }
                }
                else
                {
                    Console.WriteLine(qte + " x " + plat + " annulés !");
                }
                Console.WriteLine("Avez-vous fini ?(true/false)");
                suite = Boolean.Parse(Console.ReadLine());
            } while (suite == false);
            int NumCom = NumCommande(maConnexion);
            Console.WriteLine("\n\n\n Voici votre commande n°" + NumCom);
            Récap(ListPlat, ListQte, ListePrice, TotalPrice);
            int numC = NumCommande(maConnexion);


            // insertion
            for(int i=0;i<ListPlat.Count;i++)
            { InsertCommande(maConnexion, nom, ListPlat[i], ListQte[i], numC); }

            //retirer les produits (le site ne permet pas de refuser une commande en cas de rupture de stock et de mettre stock épuisé dans la carte)
            for (int i = 0; i < ListPlat.Count; i++)
            { Reduction(maConnexion,ListPlat[i], ListQte[i]); }
            Console.WriteLine("Vous serez livré entre 30min - 2jours en fonction de votre commande");

            // distribution de points
            for (int i = 0; i < ListPlat.Count; i++)
            { Distribution(maConnexion, ListPlat[i], ListQte[i]); }
        }

        // La partie Commander
        static int GetPrice(MySqlConnection maConnexion,string plat)
        {
            int price = 0;
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT prix FROM recette where nom_r=@Plat";
            MySqlDataReader reader;
            MySqlParameter Plat = new MySqlParameter("@Plat", MySqlDbType.VarChar);// prend le nom
            Plat.Value = plat;
            commande.Parameters.Add(Plat);
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                price = reader.GetInt32(0);
            }
            reader.Close();
            return price;
        }
        static void Récap(List<string> LS,List<int> Lqte,List<int> Lprice,int Tprice)
        {
            Console.WriteLine("Voici votre panier");
            for(int i=0;i<LS.Count;i++)
            {
                Console.WriteLine("- " + Lqte[i] + " x " + LS[i]+" => "+Lqte[i]+"x"+Lprice[i]+" = "+Lqte[i]*Lprice[i]);
            }
            Console.WriteLine("TOTAL : " + Tprice);
        }
        //return un numéro de commande
        static int NumCommande(MySqlConnection maConnexion)
        {
            int Num=0;//numéro de commande
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "select distinct num_c+1 from commander where num_c >= ALL(select num_c from commander);";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                Num = reader.GetInt32(0);
            }
            reader.Close();
            return Num;
        }
        // insert les commandes
        static void InsertCommande(MySqlConnection maConnexion,string Nom, string Nom_r, int qte,int numC)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
            MySqlParameter nom_r = new MySqlParameter("@nom_r", MySqlDbType.VarChar);
            MySqlParameter num_c = new MySqlParameter("@num_c", MySqlDbType.Int32);
            MySqlParameter period = new MySqlParameter("@period", MySqlDbType.DateTime);
            name.Value = Nom;
            nom_r.Value = Nom_r;
            num_c.Value = numC;
            period.Value = DateTime.Now;
            string insertTable = " insert into commander  Values (@name,@Nom_r,@num_c,@period);";
            commande.CommandText = insertTable;
            commande.Parameters.Add(name);
            commande.Parameters.Add(nom_r);
            commande.Parameters.Add(num_c);
            commande.Parameters.Add(period);
            for (int i = 0; i < qte; i++)
            { commande.ExecuteNonQuery(); }
        }

        // La partie reduction de produit
        static void Reduction(MySqlConnection maConnexion,string Nom_r,int Qte)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_r = new MySqlParameter("@nom_r", MySqlDbType.VarChar);
            nom_r.Value = Nom_r;
            List<string> Lnom_p = new List<string>(); // liste de produit à retirer
            List<int> Lqte = new List<int>(); // liste de quantité à retirer
            commande.CommandText = "SELECT nom_p,quantite FROM composer where nom_r=@nom_r";
            commande.Parameters.Add(nom_r);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Lnom_p.Add(reader.GetString(0));
                Lqte.Add(reader.GetInt32(1) * Qte); // composition* nb recette choisi
            }
            reader.Close();
            commande.CommandText = "UPDATE produit SET stock=stock-@qte where nom_p=@nom_p;";
            MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);
            MySqlParameter qte = new MySqlParameter("@qte", MySqlDbType.Int32);
            commande.Parameters.Add(nom_p);
            commande.Parameters.Add(qte);
            for (int i = 0; i < Lqte.Count; i++)
            {
                nom_p.Value = Lnom_p[i];
                qte.Value = Lqte[i];
                commande.ExecuteNonQuery();
            }

        }


        // La partie distribution des points cook

        static void Distribution(MySqlConnection maConnexion,string Nom_r, int Qte)
        {
            string id = ""; // id du beneficiare
            double point = 0; // point brute
            MySqlDataReader reader;
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_r = new MySqlParameter("@nom_r", MySqlDbType.VarChar);
            MySqlParameter Point = new MySqlParameter("@point", MySqlDbType.Float);
            MySqlParameter ID = new MySqlParameter("@ID", MySqlDbType.VarChar);
            nom_r.Value = Nom_r;
            commande.CommandText = "select id,prix from recette where nom_r=@nom_r;";
            commande.Parameters.Add(nom_r);
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                id = reader.GetString(0);
                int P =reader.GetInt32(1); // point brute
                point = P * Qte * 0.15; // on ne rémunere pas 2/plat mais 15% du prix
            }
            reader.Close();
            ID.Value = id;
            Point.Value = point;
            commande.CommandText = "UPDATE cdr SET point=point+@point where id=@ID;";
            commande.Parameters.Add(ID);
            commande.Parameters.Add(Point);
            { commande.ExecuteNonQuery(); }
        }


        // ajouter client
        static void AjouterClient(MySqlConnection maConnexion)
        {
            Console.WriteLine("Ajouter Client");
            client C1 = new client();
            C1.Modif();
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
            name.Value = C1.Nom;
            MySqlParameter tele = new MySqlParameter("@tele", MySqlDbType.Int64);
            tele.Value = C1.Tel;
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT nom FROM client where nom=@name";
            commande.Parameters.Add(name);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            string retire = "";
            if(reader.Read())
            {
                retire = reader.GetValue(0).ToString();
            }
            reader.Close();
            if (C1.Nom != retire)
            {
                string insertTable = " insert into client  Values (@name,@tele);";
                MySqlCommand command1 = maConnexion.CreateCommand();
                command1.CommandText = insertTable;
                command1.Parameters.Add(name);
                command1.Parameters.Add(tele);
                command1.ExecuteNonQuery();
                Console.WriteLine(C1.ToString() + " ajouté");
            }
            else
            {
                Console.WriteLine(C1.Nom + " existant");
            }
              
        }



        // modifier les données clients
        static void ModifierClient(MySqlConnection maConnexion,client C)
        {
            string ancien = C.Nom; // ancien nom
            Console.WriteLine(" Modifier votre tel\n");
            bool changeTel;
            Console.WriteLine("Changer le tel?(true/false)");
            changeTel = Convert.ToBoolean(Console.ReadLine());
            if (changeTel)
            {
                Console.WriteLine("Donnez votre nouveau num tel");
                C.Tel = Int32.Parse(Console.ReadLine());
            }
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
            MySqlParameter tele = new MySqlParameter("@tele", MySqlDbType.VarChar);
            name.Value = ancien;
            tele.Value = C.Tel;
            string modification = " update client set tel=@tele where nom=@name;";// modifie tel
            MySqlCommand command1 = maConnexion.CreateCommand();
            command1.CommandText = modification;
            command1.Parameters.Add(name);
            command1.Parameters.Add(tele);
            command1.ExecuteNonQuery();
            Console.WriteLine("le client a été modifiée.");
        }
        #endregion






        #region MODULE CDR
        static void  identificationCDR(MySqlConnection maConnexion)
        {
            string identifiant = ""; // saisir id
            string test = ""; // verifiacteur de id
            Console.WriteLine("êtes-vous un CDR ?(true/false)");
            bool commen = Boolean.Parse(Console.ReadLine());
            if (commen == false)
            { AjouterCDR(maConnexion); }
            else
            {
            Console.WriteLine("Veuillez à vous identifier !");
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = identifiant;
                Console.WriteLine("donner votre id");
                identifiant = Console.ReadLine();
                iden.Value = identifiant;
                MySqlCommand commande = maConnexion.CreateCommand();
                commande.CommandText = "SELECT id FROM cdr where id=@iden";
                commande.Parameters.Add(iden);
                MySqlDataReader reader;
                reader = commande.ExecuteReader();
                if (reader.Read())
                {
                    test = reader.GetString(0);
                }
                reader.Close();
                if (test == identifiant)
                { ModuleCDR(maConnexion, identifiant); }
                else
                { Console.WriteLine("ECHEC !!!"); }
            }
        }
        static void ModuleCDR(MySqlConnection maConnexion,string id)
        { 
            int n = 0;
            do
            {
                MessageCdr(maConnexion, id);
                AFtxt("ModuleCdr.txt");
                Console.WriteLine("choisir module");
                n = int.Parse(Console.ReadLine());
                if (n == 1)
                {
                    VoirR(maConnexion,id);
                }
                if (n == 2)
                {
                    CreerRecette(maConnexion,id);
                }
                if (n == 3)
                {
                    Lrecette(maConnexion,id);
                }
                if (n == 4)
                {
                    Suprecette(maConnexion, id);
                }
            } while (n == 1 || n == 2 || n==3 ||n==4);
        }
        static void AjouterCDR(MySqlConnection maConnexion)
        {
            Console.WriteLine(" \nAjouter un CDR\n");
            bool verif = false;
            client C = new client();
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
            name.Value = "";
            do
            {
                Console.WriteLine("donner le nom");
                name.Value = Console.ReadLine();
                MySqlCommand commande = maConnexion.CreateCommand();
                commande.CommandText = "SELECT * FROM client where nom=@name";
                commande.Parameters.Add(name);
                MySqlDataReader reader;
                reader = commande.ExecuteReader();
                if (reader.Read())
                {
                    C.Nom = reader.GetValue(0).ToString();
                    string tel = reader.GetValue(1).ToString();
                    C.Tel = Convert.ToInt32(tel);
                }
                reader.Close();
                Console.WriteLine(C.Nom + "  " + C.Tel + "  est-ce bien cela true/false ?");
                verif = Convert.ToBoolean(Console.ReadLine());
            } while (verif == false);
            cdr nouvCDR = new cdr(C.Nom, C.Tel);
            Console.WriteLine("l'admin donne l'id");
            string iden = Console.ReadLine();
            MySqlParameter id = new MySqlParameter("@id", MySqlDbType.VarChar);
            id.Value = iden;
            MySqlParameter point = new MySqlParameter("@point", MySqlDbType.Float);
            point.Value = nouvCDR.Point;
            string insertTable = " insert into cdr  Values (@id,@point,@name);";
            MySqlCommand command1 = maConnexion.CreateCommand();
            command1.CommandText = insertTable;
            command1.Parameters.Add(name);
            command1.Parameters.Add(id);
            command1.Parameters.Add(point);
            command1.ExecuteNonQuery();
            Console.WriteLine(nouvCDR.ToString() + " ajouté");


        }

        static void MessageCdr(MySqlConnection maConnexion, string id)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = id;
            commande.CommandText = "SELECT nom,point FROM cdr where id=@iden";
            commande.Parameters.Add(iden);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                Console.WriteLine("\n\n\n          BIENVENUE     " + reader.GetString(0) + "        total point: " + reader.GetInt32(1));
            }
            reader.Close();
        }

        static void VoirR(MySqlConnection maConnexion,string id)
        {
            string nom_r = "";
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = id;
            MySqlParameter rec = new MySqlParameter("@nom_r", MySqlDbType.VarChar);
            Console.WriteLine("donnez une de vos recette");
            nom_r = Console.ReadLine();
            rec.Value = nom_r;
            commande.CommandText = "SELECT * FROM recette where id=@iden and nom_r=@nom_r ";
            commande.Parameters.Add(iden);
            commande.Parameters.Add(rec);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            if (reader.Read())
            {
                Console.WriteLine("recette: " + reader.GetString(0));
                Console.WriteLine("type: " + reader.GetString(1));
                Console.WriteLine("descriptif: " + reader.GetString(2));
                Console.WriteLine("prix: " + reader.GetInt32(3));
            }
            reader.Close();
            Console.WriteLine("\n-------------COMPOSITION-------------");
            MySqlCommand commande1 = maConnexion.CreateCommand();
            commande1.CommandText = "SELECT produit.matiere,nom_p,quantite FROM composer natural join recette natural join produit where nom_r=@nom_r and id=@iden";
            commande1.Parameters.Add(rec);
            commande1.Parameters.Add(iden);
            MySqlDataReader reader1;
            reader1 = commande1.ExecuteReader();
            while (reader1.Read())
            {
                string mat = reader1.GetString(0);
                if (mat == "solide")
                { Console.WriteLine(reader1.GetInt32(2) + "  " + reader1.GetString(1)); }
                if (mat == "poudre")
                { Console.WriteLine(reader1.GetInt32(2) + " g  " + reader1.GetString(1)); }
                if (mat == "liquide")
                { Console.WriteLine(reader1.GetInt32(2) + " mL  " + reader1.GetString(1)); }
            }
            reader1.Close();
        }

        static void CreaCompo(MySqlConnection maConnexion, string nom_r)
        {
            bool fini = true;
            Console.WriteLine("\nbientot fini...");
            Console.WriteLine("\nDonnez ingrédient par ingrédient et quantité par quantité");
            int cpt = 1;
            do
            {
                MySqlCommand commande = maConnexion.CreateCommand();
                MySqlCommand commande1 = maConnexion.CreateCommand();
                MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar);
                name.Value = nom_r;
                MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);
                MySqlParameter quantite = new MySqlParameter("@quantite", MySqlDbType.Int32);
                Console.WriteLine(cpt + "ème ingrédient");           
                nom_p.Value = Console.ReadLine();
                commande.CommandText = "select matiere from produit where nom_p=@nom_p";
                commande.Parameters.Add(nom_p);
                MySqlDataReader reader;
                reader = commande.ExecuteReader();
                quantite.Value = 0;
                if (reader.Read())
                {
                    Console.WriteLine("quantité ? en "+reader.GetString(0));
                    quantite.Value = Console.ReadLine();
                }
                reader.Close();
                string insertTable = " insert into composer  Values (@name,@nom_p,@quantite);";
                MySqlCommand command1 = maConnexion.CreateCommand();
                command1.CommandText = insertTable;
                command1.Parameters.Add(name);
                command1.Parameters.Add(nom_p);
                command1.Parameters.Add(quantite);
                command1.ExecuteNonQuery();
                Console.WriteLine(cpt + " eme ingrédient Encore ? (true/false)");
                cpt++;
                fini = Boolean.Parse(Console.ReadLine());
            } while (fini == true);
        }
        static void CreerRecette(MySqlConnection maConnexion,string id)
        {
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = id;
            // début de la création
            Console.WriteLine("Commencer à créer une recette");
            string verif = "";                                         // éviter les doublons
            Recette nouvR = new Recette();
            MySqlParameter name = new MySqlParameter("@name", MySqlDbType.VarChar); // nom_r
            name.Value = "";
            do
            {
                nouvR.NomR();
                name.Value = nouvR.Nom_r;
                MySqlCommand commande = maConnexion.CreateCommand();
                commande.CommandText = "SELECT nom_r FROM recette where nom_r=@name";
                commande.Parameters.Add(name);
                MySqlDataReader reader;
                reader = commande.ExecuteReader();
                if (reader.Read())
                {
                    verif = reader.GetValue(0).ToString();
                }
                reader.Close();
                if (verif == nouvR.Nom_r)
                { Console.WriteLine("Nom existant recommencez !"); }
            } while (verif == nouvR.Nom_r);
            nouvR.typeR();
            nouvR.DesR();
            nouvR.PrixR();
            MySqlParameter type = new MySqlParameter("@type", MySqlDbType.VarChar);
            type.Value = nouvR.Type;
            MySqlParameter descr = new MySqlParameter("@descr", MySqlDbType.VarChar);
            descr.Value = nouvR.Descriptif;
            MySqlParameter prix = new MySqlParameter("@prix", MySqlDbType.Int32);
            prix.Value = nouvR.Prix;
            string insertTable = " insert into recette  Values (@name,@type,@descr,@prix,@iden);";
            MySqlCommand command1 = maConnexion.CreateCommand();
            command1.CommandText = insertTable;
            command1.Parameters.Add(name);
            command1.Parameters.Add(type);
            command1.Parameters.Add(descr);
            command1.Parameters.Add(prix);
            command1.Parameters.Add(iden);
            command1.ExecuteNonQuery();
            CreaCompo(maConnexion, nouvR.Nom_r);
            Console.WriteLine("\nMise en service\n" + nouvR.ToString());
        }

        static void Lrecette(MySqlConnection maConnexion,string id)
        {
            Console.WriteLine("\n\n          Liste de vos recette");
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = id;
            List<string> Lnom_r = new List<string>();
            List<string> Lcomp = new List<string>();
            List<int> Lcom = new List<int>();
            commande.CommandText = "SELECT nom_r FROM recette where id=@iden group by nom_r; ";
            commande.Parameters.Add(iden);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Lnom_r.Add(reader.GetString(0));
            }
            reader.Close();
            commande.CommandText = "SELECT nom_r,count(*) FROM recette natural join commander where id=@iden group by nom_r; ";
            MySqlDataReader readeR;
            readeR = commande.ExecuteReader();
            while (readeR.Read())
            {
                Lcomp.Add(readeR.GetString(0));
                Lcom.Add(readeR.GetInt32(1));
            }
            readeR.Close();
            for (int i = 0; i < Lnom_r.Count; i++)
            {
                if(Lcomp.Contains(Lnom_r[i]))
                { Console.WriteLine("recette: " + Lnom_r[i] + "   commandé: " + Lcom[Lcomp.IndexOf(Lnom_r[i])]); }
                else
                { Console.WriteLine("recette: " + Lnom_r[i] + "   commandé: " + 0); }
            }
        }
        static void Suprecette(MySqlConnection maConnexion,string id)
        {
            bool verif = false;
            string nom_r = ".";
            Console.WriteLine("Supprimer une recette");
            do
            {
                MySqlParameter nom = new MySqlParameter("@nom", MySqlDbType.VarChar);
                MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
                iden.Value = id;
                MySqlCommand commande = maConnexion.CreateCommand();
                MySqlDataReader reader;
                Console.WriteLine("donner le nom");
                nom_r = Console.ReadLine();
                nom.Value = nom_r;
                commande.CommandText = "SELECT * FROM recette where nom_r=@nom and id=@iden";
                commande.Parameters.Add(nom);
                commande.Parameters.Add(iden);
                reader = commande.ExecuteReader();
                Recette R = new Recette();
                if (reader.Read())
                {
                    R.Nom_r = reader.GetString(0);
                    R.Type = reader.GetString(1);
                    R.Descriptif = reader.GetString(2);
                    R.Prix = reader.GetFloat(3);
                }
                reader.Close();
                Console.WriteLine(R.ToString() + "\n  est-ce bien cela (supprimer) true/false ?");
                verif = Convert.ToBoolean(Console.ReadLine());
            } while (verif == false);
            bool secu = false;
            Console.WriteLine("Etes-vous sûre ? (true/false)");
            secu = Boolean.Parse(Console.ReadLine());
            if (secu)
            {
                MySqlParameter nom1 = new MySqlParameter("@nom1", MySqlDbType.VarChar);
                MySqlCommand commande1 = maConnexion.CreateCommand();
                nom1.Value = nom_r;
                commande1.CommandText = "DELETE FROM composer WHERE nom_r=@nom1";
                commande1.Parameters.Add(nom1);
                commande1.ExecuteNonQuery();
                commande1.CommandText = "DELETE FROM commander WHERE nom_r=@nom1";
                commande1.ExecuteNonQuery();
                commande1.CommandText = "DELETE FROM recette WHERE nom_r=@nom1";
                commande1.ExecuteNonQuery();
                Console.WriteLine("suppression effectuer !");
            }
            else
            {
                Console.WriteLine("Recette sauvé !");
            }
        }

        #endregion






        #region MODULE COOKING
        static void ModuleCooking(MySqlConnection maConnexion)
        {
            int n = -1;
            do
            {
                Console.WriteLine("\n");
                Console.WriteLine("BIENVENUE DANS VOTRE ESPACE (BACK-OFFICE)");
                AFtxt("ModuleCooking.txt");
                Console.WriteLine("choisir module");
                n = int.Parse(Console.ReadLine());
                if (n == 1)
                {
                    AfficherClient(maConnexion);
                }
                if (n == 2)
                {
                    ModuleProduit(maConnexion);
                }
                if (n == 3)
                {
                    UpdatePrice(maConnexion);
                }
                if (n == 4)
                {
                    SuppCDR(maConnexion);
                }
                if (n == 5)
                {
                    FichierXml(maConnexion);
                }
            } while (n == 1 || n == 2 || n == 3 || n==4 || n==5);
        }
        // affiche les clients
        static void AfficherClient(MySqlConnection maConnexion)
        {
            Console.WriteLine("La liste des CLIENTS");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT * FROM client";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            string[] valueString = new string[reader.FieldCount];
            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    valueString[i] = reader.GetValue(i).ToString();
                    Console.Write(valueString[i] + " ");
                }
                Console.WriteLine();
            }
            reader.Close();
            // nombre de client
            commande.CommandText = "SELECT count(*) FROM client";
            MySqlDataReader reader1;
            reader1 = commande.ExecuteReader();
            int nbclient = 0;
            while (reader1.Read())
            {
                nbclient = reader1.GetInt32(0);
            }
            reader1.Close();
            Console.WriteLine("il y a actuellement : " + nbclient + " clients !");
        }

        // modifie le prix
        static void UpdatePrice(MySqlConnection maConnexion)
        {
            bool verif = false;
            MySqlDataReader reader;
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_r = new MySqlParameter("@nom_r", MySqlDbType.VarChar);
            MySqlParameter upgrade = new MySqlParameter("@up", MySqlDbType.Int32);
            commande.CommandText = "select nom_r,count(nom_r) from commander group by nom_r order by count(nom_r) DESC;";
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString(0) + " commandé : " + reader.GetInt32(1));
            }
            reader.Close();
            Console.WriteLine("Voulez-vous augmenter le prix d'un plat? (true/false)");
            verif = Boolean.Parse(Console.ReadLine());
            if (verif)
            {
                Console.WriteLine(" Donnez le bon plat");
                nom_r.Value = Console.ReadLine();
                Console.WriteLine(" Voulez-vous augmenter de combien ?(int)");
                upgrade.Value = int.Parse(Console.ReadLine());
                commande.CommandText = "UPDATE recette SET prix=prix+@up where nom_r=@nom_r;";
                commande.Parameters.Add(nom_r);
                commande.Parameters.Add(upgrade);
                commande.ExecuteNonQuery();
                Console.WriteLine("modification effectuée !");
            }
            else
            { Console.WriteLine("Rien de modifier !"); }
        }

        // supprime un CDR
        static void SuppCDR(MySqlConnection maConnexion)
        {
            bool verif = false;
            string id = ""; // ID CDR
            MySqlParameter iden = new MySqlParameter("@iden", MySqlDbType.VarChar);
            iden.Value = id;
            List<string> Ses_Re = new List<string>(); // les recettes
            Console.WriteLine("Supprimer un CDR");
            do
            {
                MySqlCommand commande = maConnexion.CreateCommand();
                MySqlDataReader reader;
                Console.WriteLine("donner l'id");
                id = Console.ReadLine();
                iden.Value = id;
                commande.CommandText = "SELECT * from cdr natural join client where id=@iden";
                commande.Parameters.Add(iden);
                reader = commande.ExecuteReader();
                if (reader.Read())
                {
                    Console.WriteLine("\n"+reader.GetString(0) + "   " + reader.GetString(1) + "   " + reader.GetFloat(2) + "    " + reader.GetInt32(3));
                }
                reader.Close();

                MySqlDataReader reader1;
                commande.CommandText = "SELECT nom_r from recette where id=@iden";
                reader1 = commande.ExecuteReader();
                if (reader1.Read())
                {
                    Ses_Re.Add(reader1.GetString(0));
                }
                reader1.Close();
                Console.WriteLine( " est-ce bien cela (supprimer) true/false ?");
                verif = Convert.ToBoolean(Console.ReadLine());
            } while (verif == false);
            bool secu = false;
            Console.WriteLine("Etes-vous sûre ? (true/false)");
            secu = Boolean.Parse(Console.ReadLine());
            if (secu)
            {
                MySqlParameter nom = new MySqlParameter("@nom", MySqlDbType.VarChar); // nom_r
                MySqlCommand commande1 = maConnexion.CreateCommand();
                foreach (string n in Ses_Re)
                {
                    nom.Value = n;
                    commande1.Parameters.Add(nom);
                    commande1.CommandText = "DELETE FROM composer WHERE nom_r=@nom";
                    commande1.ExecuteNonQuery();
                    commande1.CommandText = "DELETE FROM commander WHERE nom_r=@nom";
                    commande1.ExecuteNonQuery();
                    commande1.CommandText = "DELETE FROM recette  WHERE nom_r=@nom";
                    commande1.ExecuteNonQuery();
                }
                commande1.CommandText = "DELETE FROM cdr WHERE id=@iden";
                commande1.Parameters.Add(iden);
                commande1.ExecuteNonQuery();
                Console.WriteLine(id + " banni de cdr à vie !");
            }
            else
            {
                Console.WriteLine(id+" le cdr repêché !");
            }
        }

        // Partie XML
        static List<Xml> LXML(MySqlConnection maConnexion)
        {
            List<Xml> LX = new List<Xml>();
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "select nom_f,nom_p,stock_max-stock as Com from produit where stock<=stock_min order by nom_f,nom_p;";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Xml p = new Xml(reader.GetString(0),reader.GetString(1),reader.GetInt32(2));
                LX.Add(p);
            }
            reader.Close();
            return LX;
        }
        static void FichierXml(MySqlConnection maConnexion)
        {
            List<Xml> LX = new List<Xml>();
            LX = LXML(maConnexion);

            // SERIALISATION
            XmlSerializer xs = new XmlSerializer(typeof(Xml));
            using (StreamWriter wr = new StreamWriter("test.xml"))
            {
                foreach (Xml x in LX)
                {
                    xs.Serialize(wr, x);
                    Console.WriteLine(x.ToString());
                }
            }
            /*
            TextWriter writer = new StreamWriter("test.xml");
            ser.Serialize(writer, LX[0]);
            writer.Close();*/
            //affichage

        }
        #endregion


        #region PRODUIT
        static void ModuleProduit(MySqlConnection maConnexion)
        {
            int n = -1;
            do
            {
                Console.WriteLine("\n");
                AFtxt("ModuleProduit.txt");
                Console.WriteLine("choisir module");
                n = int.Parse(Console.ReadLine());
                if (n == 1)
                {
                    AfficherProduit(maConnexion);
                }
                if (n == 2)
                {
                    ReduireProduit(maConnexion);
                }
                if (n == 3)
                {
                    ComProduit(maConnexion);
                }
                if (n == 4)
                {
                    AjProduit(maConnexion);
                }
                if (n == 5)
                {
                    AjFournisseur(maConnexion);
                }
            } while (n == 1 || n == 2 || n==3 || n==4 || n==5);
        }
        // dans l'ordre alphabetique
        static void AfficherProduit(MySqlConnection maConnexion)
        {
            Console.WriteLine("La liste des Produits");
            MySqlCommand commande = maConnexion.CreateCommand();
            commande.CommandText = "SELECT nom_p,categorie,stock, stock_min,stock_max,nom_f FROM produit order by nom_f";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            List<Produit> Lp = new List<Produit>();
            while (reader.Read())
            {
                Produit P = new Produit(reader.GetString(0), reader.GetString(1), reader.GetInt32(2), reader.GetInt32(3), reader.GetInt32(4),reader.GetString(5));
                Lp.Add(P);
            }
            reader.Close();
            foreach(Produit P in Lp)
            {
                Console.WriteLine(P.ToString());
            }
           
        }

        static void ComProduit(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);
            Console.WriteLine("Commander un Produit");
            Console.WriteLine("Donnez le nom du produit");
            string nomP = Console.ReadLine();
            nom_p.Value = nomP;
            commande.CommandText = "SELECT nom_p,stock,nom_f FROM produit where nom_p=@nom_p";
            commande.Parameters.Add(nom_p);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            bool verif = false;
            if (reader.Read())
            {
                verif = true;
                Console.WriteLine(reader.GetString(0) + "   quantité : " + reader.GetInt32(1));
                Console.WriteLine("il faut commander chez " + reader.GetString(2));
            }
            reader.Close();
            if (verif)
            {
                Console.WriteLine("donner la quantité en plus");
                int qt = int.Parse(Console.ReadLine());
                MySqlParameter qte = new MySqlParameter("@qte", MySqlDbType.Int32);
                qte.Value = qt;
                commande.CommandText = "UPDATE produit SET stock=stock+@qte where nom_p=@nom_p;";
                commande.Parameters.Add(qte);
                commande.ExecuteNonQuery();
                Console.WriteLine(nomP + " " + qt + " en plus !");
            }
        }

        static void ReduireProduit(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);
            Console.WriteLine("Reduire un Produit");
            Console.WriteLine("Donnez le nom du produit");
            string nomP = Console.ReadLine();
            nom_p.Value = nomP;
            commande.CommandText = "SELECT nom_p,stock FROM produit where nom_p=@nom_p";
            commande.Parameters.Add(nom_p);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            bool verif = false;
            if (reader.Read())
            {
                verif = true;
                Console.WriteLine(reader.GetString(0) + "   quantité : " + reader.GetInt32(1));
            }
            reader.Close();
            if (verif)
            {
                Console.WriteLine("donner la quantité en moins");
                int qt = int.Parse(Console.ReadLine());
                MySqlParameter qte = new MySqlParameter("@qte", MySqlDbType.Int32);
                qte.Value = qt;
                commande.CommandText = "UPDATE produit SET stock=stock-@qte where nom_p=@nom_p;";
                commande.Parameters.Add(qte);
                commande.ExecuteNonQuery();
                Console.WriteLine(nom_p + " " + qt + " en moins !");
            }
        }
        
        // ajouter un produit
        static void AjProduit(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            MySqlParameter nom_p = new MySqlParameter("@nom_p", MySqlDbType.VarChar);
            Console.WriteLine("Ajouter Produit");
            Produit P = new Produit();
            Console.WriteLine("Donnez le nom du produit");
            string nomP = Console.ReadLine();
            nom_p.Value = nomP;
            commande.CommandText = "SELECT nom_p FROM produit where nom_p=@nom_p";
            commande.Parameters.Add(nom_p);
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            bool verif = true;
            if (reader.Read())
            {
                verif = false;
                Console.WriteLine(reader.GetString(0) + " produit existant !");
            }
            reader.Close();
            if (verif)
            {
                Console.WriteLine("catégorie d'article ?");
                string cat = Console.ReadLine();
                Console.WriteLine("matière ? (liquide,poudre,solide)");
                string mat = Console.ReadLine();
                int stock = 0;
                if(mat=="liquide")
                {
                    Console.WriteLine(mat + " en mL");
                    stock = int.Parse(Console.ReadLine());
                }
                if (mat == "poudre")
                {
                    Console.WriteLine(mat + " en g");
                    stock = int.Parse(Console.ReadLine());
                }
                if (mat == "solide")
                {
                    Console.WriteLine(mat + " piece");
                    stock = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("stock min ?");
                int stock_min = int.Parse(Console.ReadLine());
                Console.WriteLine("stock max?");
                int stock_max = int.Parse(Console.ReadLine());
                Console.WriteLine("le fournisseur ?");
                string nom_f = Console.ReadLine();
                string insertTable = " insert into produit  Values (@nom_p,@Cat,@Mat,@Stock,@S_m,@S_Max,@Nom_f);";
                MySqlCommand commande1 = maConnexion.CreateCommand();
                commande1.CommandText = insertTable;
                MySqlParameter Cat = new MySqlParameter("@Cat", MySqlDbType.VarChar);
                Cat.Value = cat;
                MySqlParameter Mat = new MySqlParameter("@Mat", MySqlDbType.VarChar);
                Mat.Value = mat;
                MySqlParameter Stock = new MySqlParameter("@Stock", MySqlDbType.Int32);
                Stock.Value = stock;
                MySqlParameter S_m = new MySqlParameter("@S_m", MySqlDbType.Int32);
                S_m.Value = stock_min;
                MySqlParameter S_Max = new MySqlParameter("@S_Max", MySqlDbType.Int32);
                S_Max.Value = stock_max;
                MySqlParameter Nom_f = new MySqlParameter("@Nom_f", MySqlDbType.VarChar);
                Nom_f.Value = nom_f;
                commande1.Parameters.Add(nom_p);
                commande1.Parameters.Add(Cat);
                commande1.Parameters.Add(Mat);
                commande1.Parameters.Add(Stock);
                commande1.Parameters.Add(S_m);
                commande1.Parameters.Add(S_Max);
                commande1.Parameters.Add(Nom_f);
                commande1.ExecuteNonQuery();
                Console.WriteLine("produit ajouté");
            }
            

        }

        // ajouter fournisseur
        static void AjFournisseur(MySqlConnection maConnexion)
        {
            MySqlCommand commande = maConnexion.CreateCommand();
            Console.WriteLine("Liste des Fournisseurs");
            commande.CommandText = "SELECT nom_f,numtel FROM fournisseurs";
            MySqlDataReader reader;
            reader = commande.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(reader.GetString(0),reader.GetInt32(1));
            }
            reader.Close();
            Console.WriteLine("Fournisseur en plus?(true/false)");
            bool aj = Boolean.Parse(Console.ReadLine());
            if(aj)
            {
                Console.WriteLine("Donnez le nom");
                MySqlParameter nom_f = new MySqlParameter("@nom_f", MySqlDbType.VarChar);
                nom_f.Value = Console.ReadLine();
                Console.WriteLine("Donnez le numtel");
                MySqlParameter tele = new MySqlParameter("@tele", MySqlDbType.VarChar);
                tele.Value = Console.ReadLine();
                string insertTable = " insert into fournisseurs  Values (@nom_f,@tele);";
                MySqlCommand command1 = maConnexion.CreateCommand();
                command1.CommandText = insertTable;
                command1.Parameters.Add(nom_f);
                command1.Parameters.Add(tele);
                command1.ExecuteNonQuery();
                Console.WriteLine("ajouté");
            }
        }
        #endregion





        static void Main(string[] args)
        {
            string connexionString = "SERVER=localhost;PORT=3306;DATABASE=Cooking;UID=root;PASSWORD=iD8DBQBeFL3pjHGNO1By4fURAt2yAKCFs5XrQlaTBqE1f536MgL2fxNiCQCgkPM+; ";
            MySqlConnection maConnexion = new MySqlConnection(connexionString);
            maConnexion.Open();
            Choix(maConnexion);
            maConnexion.Close();
            Console.ReadKey();
        }
    }
}
