﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM_Cooking
{
    interface IComparable
    {
        int CompareTo(object val);
    }
}
