﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM_Cooking
{
    class Retire
    {
        private string nom_p;
        private int qte;
        public Retire()
        { }
        public Retire(string nom_p,int qte)
        { 
            this.Nom_p = nom_p;
            this.Qte = qte;
        }

        public string Nom_p { get => nom_p; set => nom_p = value; }
        public int Qte { get => qte; set => qte = value; }
    }
}
